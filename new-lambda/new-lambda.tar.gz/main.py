from __future__ import print_function

import boto3

def handler(event, context):

    sqs = boto3.resource('sqs')
    print(sqs)
