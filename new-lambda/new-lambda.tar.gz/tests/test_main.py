import pytest

def test_handler():
    assert True
